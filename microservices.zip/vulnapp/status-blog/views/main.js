const { status } = req.body;
const username = req.session.username;

// Escape user-generated content before sending it to the backend API
const escapedStatus = escapeHTML(status);

// Construct the URL for the backend API endpoint to add a new post
const url = `${BASE_API_URL}/status`;

// Make a POST request to the backend API endpoint
const apiRequest = http.request(url, {
  method: 'POST',
  headers: {"Content-Type": 'application/x-www-form-urlencoded; charset=UTF-8'}
}, (response) => {
  response.on("data", (data) => {
    console.log(`Response from adding post: ${data.toString()}`);
    // Optionally, you can handle the response here
    // For example, redirect to a different page or send a response to the client
    res.redirect('/');
  });
});

// Send the post data as data in the request body
apiRequest.write(`username=${username}&status=${escapedStatus}`);
apiRequest.end();

// Function to escape HTML characters
function escapeHTML(html) {
  const div = document.createElement('div');
  div.appendChild(document.createTextNode(html));
  return div.innerHTML;
}
