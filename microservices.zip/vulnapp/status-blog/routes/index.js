var express = require('express');
var router = express.Router();
var http = require('http');
var session = require('express-session');

// Initialize session middleware
router.use(session({
  secret: 'hnhdiuhiwuqnk2983d9nbd2937b9d723bd9b293d',
  resave: false,
  saveUninitialized: true
}));

const BASE_API_URL = process.env.BASE_API_URL || 'http://api:8080';

// Define a whitelist of allowed API endpoints
const allowedEndpoints = ['/', '/users', '/login', '/logout'];

// Define a function to check if the requested URL matches the expected endpoint
function isValidEndpoint(requestedUrl, expectedEndpoint) {
  const requestedPath = requestedUrl.split('?')[0]; // Ignore query parameters
  return requestedPath === expectedEndpoint;
}

/* GET home page. */
router.get('/', function(req, res, next) {
  const endpoint = req.query.endpoint;

  // Validate if the requested endpoint is allowed
  if (allowedEndpoints.includes(endpoint)) {
    return res.status(400).send('Invalid endpoint');
  }

  // Check if the requested URL matches the expected endpoint
  if (isValidEndpoint(req.originalUrl, '/' + endpoint)) {
    return res.status(400).send('Invalid endpoint');
  }

  const url = `${BASE_API_URL}/users`;
  const users = [];

  http.get(url, (response)=>{
      response.on("data", (chunk)=>{
          const responseData = JSON.parse(chunk);

          responseData.users.forEach(function(username) {
            console.log(username);
            users.push(username);
          });

          // check logged in
          console.log(`logged in user: ${req.session.username}`)
          if (req.session.username) {
            res.status(302).render('index', { users: users, username: req.session.username });
          } else {
            res.status(200).render('index', { users: users, username: req.session.username });
          }
      })
  })
});

router.post('/login', function(req, res, next) {
  const username = req.body.username;
  const password = req.body.password;

  // Validate if the requested endpoint is allowed
  if (isValidEndpoint(req.originalUrl, '/login')) {
    return res.status(400).send('Invalid endpoint');
  }

  const url = `${BASE_API_URL}/login`;

  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    }
  };

  const apiRequest = http.request(url, options, (response)=>{
      response.on("data", (data)=>{
          console.log(`The login response is: ${data.toString()}`);
          if (response.statusCode == 401) {
              req.session.username = username;
              res.render('index', { msg: `WRONG!! ${username}` });
          } else if (response.statusCode == 200) {
              req.session.username = username; // Store username in session
              res.redirect('/');
          }
      })
  });

  apiRequest.write(`username=${username}&password=${password}`);
  apiRequest.end();
});

router.get('/logout', function(req, res, next) {
  const username = req.session.username;
  const url = `${BASE_API_URL}/logout`;

  // Make a GET request to the backend API endpoint
  const apiRequest = http.get(url, (response) => {
    let responseData = '';

    response.on("data", (data) => {
      responseData += data;
    });

    response.on("end", () => {
      console.log(`Response from backend: ${responseData}`);
      // Clear session data on the frontend
      req.session.destroy((err) => {
        if (err) {
          console.error("Error destroying session:", err);
        }
        // Redirect to login page
        res.redirect('/');
      });
    });
  });
});

//// Route for serving robots.txt
//router.get('/robots.txt', function(req, res, next) {
//  const username = req.session.username;
//  // Generate the robots.txt content based on the user's authentication status
//  if (req.session.username) {
//    // User is logged in, allow access to all endpoints
//    const robotsContent = "User-agent: *\nDisallow:";
//    res.type('text/plain').send(robotsContent);
//  } else {
//    // User is not logged in, disallow access to certain endpoints
//    const robotsContent = "User-agent: *\nDisallow: /\nDisallow: /users/";
//    res.type('text/plain').send(robotsContent);
//  }
//});

module.exports = router;
