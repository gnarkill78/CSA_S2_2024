var express = require('express');
var http = require('http');
var router = express.Router();
var session = require('express-session');

// Initialize session middleware
router.use(session({
  secret: 'hnhdiuhiwuqnk2983d9nbd2937b9d723bd9b293d',
  resave: false,
  saveUninitialized: true
}));

const querystring = require('querystring');
const BASE_API_URL = process.env.BASE_API_URL || 'http://api:8080';

// Define a whitelist of allowed API endpoints
const allowedEndpoints = ['/', '/users', '/login', '/status'];

// Define a function to check if the requested URL matches the expected endpoint
function isValidEndpoint(requestedUrl, expectedEndpoint) {
  const requestedPath = requestedUrl.split('?')[0]; // Ignore query parameters
  return requestedPath === expectedEndpoint;
}

router.get('/', function(req, res, next) {
  const endpoint = req.query.endpoint;

  // Validate if the requested endpoint is allowed
  if (allowedEndpoints.includes(endpoint)) {
    return res.status(400).send('Invalid endpoint');
  }

  // Check if the requested URL matches the expected endpoint
  if (isValidEndpoint(req.originalUrl, '/' + endpoint)) {
    return res.status(400).send('Invalid endpoint');
  }

  // res.send('respond with a resource');
  const requestString = req.query.request;
//  const url = `${BASE_API_URL}/${requestString}`
  const url = `http://api:8080/${requestString}`
  // var status;

  http.get(url, (response)=>{
      response.on("data", (chunk)=>{
          const responseData = JSON.parse(chunk);
          var status = responseData.status;
          console.log(`Status request response: ${status}`);
          res.send(`${status}`);
      })
  })

  // res.write(`${status}`);
  // console.log(status);
  // res.send(`${status}`);

});

router.post('/login', function(req, res, next) {
  const username = req.body.username;
  const password = req.body.password;
  // Validate if the requested endpoint is allowed
  if (isValidEndpoint(req.originalUrl, '/login')) {
    return res.status(400).send('Invalid endpoint');
  }

  const url = `${BASE_API_URL}/login`;

  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
//      'X-CSRF-Token': csrfToken
//      'API-Key': '980u9wdhc978wh9hbf9w7hb97fhw9e7fb'
    }
  };

  const apiRequest = http.request(url, options, (response)=>{
      response.on("data", (data)=>{
          console.log(`login response: ${data.toString()}`);
          if (response.statusCode == 401) {
              req.session.username = username;
              res.render('index', { msg: `You have entered the wrong credentials. ${username}` });
          } else if (response.statusCode == 200) {
              req.session.username = username; // Store username in session
              res.redirect('/');
          } else if (response.statusCode == 302) {
              req.session.username = username; // Store username in session
              res.redirect('/');
          }
      })
  });

  apiRequest.write(`username=${username}&password=${password}`);
  apiRequest.end();
});

router.post('/status', function(req, res, next) {
  const { status } = req.body; // Assuming your form sends username and status
  const username = req.session.username;
  console.log(`The user that is posting is: ${username}`);
  console.log(`Status being added is: ${status}`);

  // Validate if the requested endpoint is allowed
  if (isValidEndpoint(req.originalUrl, '/status')) {
    return res.status(400).send('Invalid endpoint');
  }

  // Construct the URL for the backend API endpoint to add a new post
  const url = `${BASE_API_URL}/status`;

  // Prepare the post data
  const postData = querystring.stringify({
    username: username,
    status: status
  });

  // Make a POST request to the backend API endpoint
  const apiRequest = http.request(url, {
    method: 'POST',
    headers: {
      "Content-Type": 'application/x-www-form-urlencoded; charset=UTF-8',
      "Content-Length": Buffer.byteLength(postData)
    }
  }, (response) => {
    let responseData = '';

    // Accumulate data chunks
    response.on("data", (chunk) => {
      responseData += chunk;
    });

    // Handle the end of the response
    response.on("end", () => {
      console.log(`Response from adding post: ${responseData}`);
      if (response.statusCode === 200) {
        // Successfully added post, redirect to the homepage or another page
        res.redirect('/users?request=status%3fusername%3dtestuser');
      } else {
        // Handle error response from backend API
        res.status(response.statusCode).send(`Error: ${responseData}`);
      }
    });
  });

  // Handle request errors
  apiRequest.on('error', (error) => {
    console.error(`Error making API request: ${error.message}`);
    res.status(500).send('Internal Server Error');
  });

  // Send the post data
  apiRequest.write(postData);
  apiRequest.end();
});

router.get('/logout', function(req, res, next) {
  const username = req.session.username;
  const url = `${BASE_API_URL}/logout`;

  // Make a GET request to the backend API endpoint
  const apiRequest = http.get(url, (response) => {
    let responseData = '';

    response.on("data", (data) => {
      responseData += data;
    });

    response.on("end", () => {
      console.log(`Response from backend: ${responseData}`);
      // Clear session data on the frontend
      req.session.destroy((err) => {
        if (err) {
          console.error("Error destroying session:", err);
        }
        // Redirect to login page
        res.redirect('/');
      });
    });
  });
});

module.exports = router;
