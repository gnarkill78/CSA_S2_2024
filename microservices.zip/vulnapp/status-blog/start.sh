export REDIS_URI=$REDIS_URI
echo "Redis URI passed: $REDIS_URI"
npm start
